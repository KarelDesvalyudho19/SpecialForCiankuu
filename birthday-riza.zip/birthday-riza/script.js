/* ==============================================
   BIRTHDAY WEBSITE — SCRIPT.JS
   Website Ucapan Ulang Tahun Riza Aisyah Fitri
   ============================================== */

// ---- Referensi Elemen ----
const landing      = document.getElementById('landing');
const btnOpen      = document.getElementById('btn-open');
const bgMusic      = document.getElementById('bg-music');
const musicToggle  = document.getElementById('music-toggle');
const musicIcon    = musicToggle.querySelector('.music-icon');
const typingText   = document.getElementById('typing-text');
const envelope     = document.getElementById('envelope');
const letterContent= document.getElementById('letter-content');
const giftBox      = document.getElementById('gift-box');
const balloonsC    = document.getElementById('balloons-container');
const carouselTrack= document.getElementById('carousel-track');
const prevBtn      = document.getElementById('prev-btn');
const nextBtn      = document.getElementById('next-btn');
const dotsContainer= document.getElementById('carousel-dots');
const canvas       = document.getElementById('petals-canvas');
const ctx          = canvas.getContext('2d');

// ---- State ----
let isMuted      = false;
let musicStarted = false;
let currentSlide = 0;

// ==============================================
// 1. CANVAS — ANIMASI KELOPAK & HATI
// ==============================================

// Resize canvas
function resizeCanvas() {
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

// Partikel kelopak/hati
const petals = [];
const PETAL_COUNT = 35;

// Warna kelopak
const petalColors = [
  'rgba(248, 164, 200, 0.6)',
  'rgba(224, 108, 159, 0.5)',
  'rgba(201, 167, 235, 0.5)',
  'rgba(155, 109, 215, 0.4)',
  'rgba(245, 199, 110, 0.4)',
  'rgba(252, 213, 229, 0.5)',
];

class Petal {
  constructor() {
    this.reset();
    // Mulai di posisi acak saat pertama kali
    this.y = Math.random() * canvas.height;
  }

  reset() {
    this.x      = Math.random() * canvas.width;
    this.y      = -20;
    this.size   = Math.random() * 12 + 6;
    this.speed  = Math.random() * 1 + 0.3;
    this.wind   = Math.random() * 0.8 - 0.4;
    this.angle  = Math.random() * Math.PI * 2;
    this.spin   = (Math.random() - 0.5) * 0.02;
    this.opacity= Math.random() * 0.5 + 0.3;
    this.color  = petalColors[Math.floor(Math.random() * petalColors.length)];
    // Tipe: 'petal' atau 'heart'
    this.type   = Math.random() > 0.35 ? 'petal' : 'heart';
  }

  update() {
    this.y     += this.speed;
    this.x     += this.wind + Math.sin(this.angle) * 0.3;
    this.angle += this.spin;

    if (this.y > canvas.height + 20) {
      this.reset();
    }
  }

  draw() {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.angle);
    ctx.globalAlpha = this.opacity;

    if (this.type === 'heart') {
      this.drawHeart();
    } else {
      this.drawPetal();
    }

    ctx.restore();
  }

  drawPetal() {
    ctx.beginPath();
    ctx.ellipse(0, 0, this.size * 0.5, this.size, 0, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
  }

  drawHeart() {
    const s = this.size * 0.4;
    ctx.beginPath();
    ctx.moveTo(0, s * 0.4);
    ctx.bezierCurveTo(-s, -s * 0.4, -s * 1.5, s * 0.6, 0, s * 1.4);
    ctx.bezierCurveTo(s * 1.5, s * 0.6, s, -s * 0.4, 0, s * 0.4);
    ctx.fillStyle = this.color;
    ctx.fill();
  }
}

// Buat partikel
for (let i = 0; i < PETAL_COUNT; i++) {
  petals.push(new Petal());
}

// Loop animasi
function animatePetals() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (const p of petals) {
    p.update();
    p.draw();
  }
  requestAnimationFrame(animatePetals);
}
animatePetals();

// ==============================================
// 2. TOMBOL BUKA — LANDING PAGE
// ==============================================

btnOpen.addEventListener('click', () => {
  // Putar musik
  if (!musicStarted) {
    bgMusic.play().catch(() => {
      // Autoplay blocked — tetap lanjutkan
      console.log('Autoplay blocked, user bisa klik tombol musik.');
    });
    musicStarted = true;
  }

  // Sembunyikan landing
  landing.classList.add('hidden');

  // Setelah transisi selesai, hilangkan dari DOM flow
  setTimeout(() => {
    landing.style.display = 'none';
    // Mulai typing animation
    startTyping();
  }, 1200);

  // Scroll ke greeting
  setTimeout(() => {
    document.getElementById('greeting').scrollIntoView({ behavior: 'smooth' });
  }, 600);
});

// ==============================================
// 3. TYPING ANIMATION — UCAPAN UTAMA
// ==============================================

const typingMessage = 'Selamat Ulang Tahun, Ciankuuu Naburjuuu!';
let typingIndex = 0;

function startTyping() {
  typingIndex = 0;
  typingText.textContent = '';
  typeNextChar();
}

function typeNextChar() {
  if (typingIndex < typingMessage.length) {
    typingText.textContent += typingMessage.charAt(typingIndex);
    typingIndex++;
    setTimeout(typeNextChar, 75);
  } else {
    // Typing selesai
    typingText.classList.add('typing-done');
    // Tampilkan elemen lainnya
    setTimeout(() => {
      document.querySelector('.greeting-age').classList.add('visible');
      document.querySelector('.greeting-hearts').classList.add('visible');
      document.querySelector('.greeting-wish').classList.add('visible');
    }, 400);
  }
}

// ==============================================
// 4. TOMBOL MUSIK (MUTE / UNMUTE)
// ==============================================

musicToggle.addEventListener('click', () => {
  if (!musicStarted) {
    bgMusic.play().catch(() => {});
    musicStarted = true;
    isMuted = false;
    musicIcon.textContent = '🔊';
    musicToggle.classList.remove('muted');
    return;
  }

  isMuted = !isMuted;
  bgMusic.muted = isMuted;
  musicIcon.textContent = isMuted ? '🔇' : '🔊';
  musicToggle.classList.toggle('muted', isMuted);
});

// ==============================================
// 5. GALERI CAROUSEL
// ==============================================

const slides    = document.querySelectorAll('.carousel-slide');
const totalSlides = slides.length;

// Buat dots
function createDots() {
  for (let i = 0; i < totalSlides; i++) {
    const dot = document.createElement('button');
    dot.classList.add('carousel-dot');
    dot.setAttribute('aria-label', `Foto ${i + 1}`);
    if (i === 0) dot.classList.add('active');
    dot.addEventListener('click', () => goToSlide(i));
    dotsContainer.appendChild(dot);
  }
}
createDots();

function updateCarousel() {
  carouselTrack.style.transform = `translateX(-${currentSlide * 100}%)`;
  // Update dots
  const dots = dotsContainer.querySelectorAll('.carousel-dot');
  dots.forEach((d, i) => d.classList.toggle('active', i === currentSlide));
}

function goToSlide(index) {
  currentSlide = index;
  updateCarousel();
}

prevBtn.addEventListener('click', () => {
  currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
  updateCarousel();
});

nextBtn.addEventListener('click', () => {
  currentSlide = (currentSlide + 1) % totalSlides;
  updateCarousel();
});

// Auto-slide setiap 5 detik
let autoSlideInterval = setInterval(() => {
  currentSlide = (currentSlide + 1) % totalSlides;
  updateCarousel();
}, 5000);

// Pause auto-slide saat hover
const galleryCarousel = document.querySelector('.gallery-carousel');
galleryCarousel.addEventListener('mouseenter', () => clearInterval(autoSlideInterval));
galleryCarousel.addEventListener('mouseleave', () => {
  autoSlideInterval = setInterval(() => {
    currentSlide = (currentSlide + 1) % totalSlides;
    updateCarousel();
  }, 5000);
});

// Swipe support untuk mobile
let touchStartX = 0;
let touchEndX   = 0;

galleryCarousel.addEventListener('touchstart', (e) => {
  touchStartX = e.changedTouches[0].screenX;
}, { passive: true });

galleryCarousel.addEventListener('touchend', (e) => {
  touchEndX = e.changedTouches[0].screenX;
  const diff = touchStartX - touchEndX;
  if (Math.abs(diff) > 50) {
    if (diff > 0) {
      // Swipe kiri → next
      currentSlide = (currentSlide + 1) % totalSlides;
    } else {
      // Swipe kanan → prev
      currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    }
    updateCarousel();
  }
}, { passive: true });

// ==============================================
// 6. SURAT — EFEK BUKA AMPLOP
// ==============================================

envelope.addEventListener('click', () => {
  if (envelope.classList.contains('opened')) return;

  envelope.classList.add('opened');

  // Tampilkan isi surat setelah amplop terbuka
  setTimeout(() => {
    letterContent.classList.add('visible');
  }, 600);
});

// ==============================================
// 7. GIFT BOX — CONFETTI
// ==============================================

giftBox.addEventListener('click', fireConfetti);
giftBox.addEventListener('keypress', (e) => {
  if (e.key === 'Enter' || e.key === ' ') fireConfetti();
});

function fireConfetti() {
  // Efek shake pada gift box
  giftBox.style.animation = 'shake 0.5s ease';
  setTimeout(() => { giftBox.style.animation = ''; }, 500);

  // Cek apakah confetti library tersedia
  if (typeof confetti === 'function') {
    // Burst 1
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f8a4c8', '#e06c9f', '#c9a7eb', '#9b6dd7', '#f5c76e', '#fcd5e5'],
    });

    // Burst 2 (sedikit delay)
    setTimeout(() => {
      confetti({
        particleCount: 50,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#f8a4c8', '#e06c9f', '#c9a7eb', '#f5c76e'],
      });
    }, 200);

    setTimeout(() => {
      confetti({
        particleCount: 50,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#f8a4c8', '#e06c9f', '#c9a7eb', '#f5c76e'],
      });
    }, 400);
  } else {
    // Fallback: custom confetti
    createFallbackConfetti();
  }
}

// CSS shake keyframe (inject secara dinamis)
const shakeStyle = document.createElement('style');
shakeStyle.textContent = `
  @keyframes shake {
    0%, 100% { transform: translateX(0); }
    10%, 30%, 50%, 70%, 90% { transform: translateX(-6px); }
    20%, 40%, 60%, 80% { transform: translateX(6px); }
  }
`;
document.head.appendChild(shakeStyle);

// Fallback confetti (kalau CDN gagal)
function createFallbackConfetti() {
  const colors = ['#f8a4c8', '#e06c9f', '#c9a7eb', '#9b6dd7', '#f5c76e', '#fcd5e5'];
  for (let i = 0; i < 40; i++) {
    const c = document.createElement('div');
    c.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      width: ${Math.random() * 10 + 5}px;
      height: ${Math.random() * 10 + 5}px;
      background: ${colors[Math.floor(Math.random() * colors.length)]};
      border-radius: ${Math.random() > 0.5 ? '50%' : '2px'};
      pointer-events: none;
      z-index: 9999;
      animation: confetti-fall ${Math.random() * 2 + 1.5}s ease-out forwards;
      transform: translate(${(Math.random() - 0.5) * 400}px, ${-Math.random() * 300 - 100}px)
                 rotate(${Math.random() * 720}deg);
    `;
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 3500);
  }
}

// Fallback confetti animation
const confettiFallStyle = document.createElement('style');
confettiFallStyle.textContent = `
  @keyframes confetti-fall {
    0% {
      opacity: 1;
      transform: translate(0, 0) rotate(0deg);
    }
    100% {
      opacity: 0;
      transform: translate(var(--tx, 100px), var(--ty, 300px)) rotate(720deg);
    }
  }
`;
document.head.appendChild(confettiFallStyle);

// ==============================================
// 8. BALON INTERAKTIF
// ==============================================

const balloonColors = [
  'linear-gradient(180deg, #f8a4c8 0%, #e06c9f 100%)',
  'linear-gradient(180deg, #c9a7eb 0%, #9b6dd7 100%)',
  'linear-gradient(180deg, #fcd5e5 0%, #f8a4c8 100%)',
  'linear-gradient(180deg, #ebe0ff 0%, #c9a7eb 100%)',
  'linear-gradient(180deg, #f5c76e 0%, #e8a84c 100%)',
  'linear-gradient(180deg, #f0b0c8 0%, #d88aa8 100%)',
  'linear-gradient(180deg, #b8a0e0 0%, #9070c0 100%)',
  'linear-gradient(180deg, #ffe5a0 0%, #f5c76e 100%)',
];

const popEmojis = ['💖', '🎉', '✨', '🌸', '💕', '🎈', '💗', '🌟'];

function createBalloons() {
  balloonsC.innerHTML = '';
  const count = 8;

  for (let i = 0; i < count; i++) {
    const balloon = document.createElement('div');
    balloon.classList.add('balloon');
    balloon.style.background = balloonColors[i % balloonColors.length];
    balloon.setAttribute('role', 'button');
    balloon.setAttribute('aria-label', `Balon ${i + 1}`);
    balloon.setAttribute('tabindex', '0');

    balloon.addEventListener('click', () => popBalloon(balloon, i));
    balloon.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' || e.key === ' ') popBalloon(balloon, i);
    });

    balloonsC.appendChild(balloon);
  }
}
createBalloons();

function popBalloon(balloon, index) {
  if (balloon.classList.contains('popped')) return;

  balloon.classList.add('popped');

  // Emoji pop
  const emoji = document.createElement('span');
  emoji.classList.add('pop-text');
  emoji.textContent = popEmojis[index % popEmojis.length];
  emoji.style.left = balloon.offsetLeft + balloon.offsetWidth / 2 + 'px';
  emoji.style.top  = balloon.offsetTop + 'px';
  balloonsC.appendChild(emoji);

  setTimeout(() => emoji.remove(), 1000);

  // Hapus balon setelah animasi
  setTimeout(() => {
    balloon.remove();
    // Jika semua balon habis, buat ulang
    if (balloonsC.querySelectorAll('.balloon').length === 0) {
      setTimeout(createBalloons, 800);
    }
  }, 500);
}

// ==============================================
// 9. SCROLL REVEAL — ANIMASI SAAT SCROLL
// ==============================================

// Tandai elemen yang perlu reveal
const revealTargets = [
  '.gallery',
  '.letter',
  '.interactive',
  '.closing',
];

// Tambah class 'reveal' ke setiap section target
revealTargets.forEach((selector) => {
  const el = document.querySelector(selector);
  if (el) {
    el.classList.add('reveal');
  }
});

// Intersection Observer untuk reveal
const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        revealObserver.unobserve(entry.target);
      }
    });
  },
  {
    threshold: 0.15,
    rootMargin: '0px 0px -50px 0px',
  }
);

document.querySelectorAll('.reveal').forEach((el) => {
  revealObserver.observe(el);
});

// ==============================================
// 10. PLACEHOLDER IMAGE HANDLER
// ==============================================

// Buat placeholder gradient untuk gambar yang belum ada
document.querySelectorAll('.carousel-img, .closing-photo').forEach((img) => {
  img.addEventListener('error', function () {
    // Tampilkan placeholder gradient + emoji
    this.style.display = 'none';
    const parent = this.parentElement;
    parent.style.display = 'flex';
    parent.style.alignItems = 'center';
    parent.style.justifyContent = 'center';
    parent.style.background =
      'linear-gradient(135deg, rgba(107, 63, 160, 0.3), rgba(184, 57, 107, 0.3))';
    parent.style.fontSize = '3rem';

    // Tambah emoji placeholder
    if (!parent.querySelector('.placeholder-emoji')) {
      const span = document.createElement('span');
      span.classList.add('placeholder-emoji');
      span.textContent = '📷';
      span.style.opacity = '0.5';
      span.style.filter = 'grayscale(30%)';
      parent.appendChild(span);
    }
  });
});

// ==============================================
// SELESAI! 🎉
// Untuk mengedit:
// - Ganti nama/tanggal di index.html
// - Ganti file foto (foto1.jpg, foto2.jpg, dst.)
// - Ganti music.mp3 dengan lagu pilihan kamu
// - Edit isi surat di bagian .letter-body di index.html
// ==============================================
